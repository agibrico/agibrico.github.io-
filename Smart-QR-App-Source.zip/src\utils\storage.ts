import { 
  QRCodeItem, 
  QRContent,
  QRType,
  ScanEvent,
  ClientProfile, 
  HistoryLogItem, 
  DesignerProfile, 
  CardModelId, 
  CardFormat 
} from '../types/qr';
import { 
  CANAAN_SERVICES_LOGO, 
  AGB_ENGINEERING_LOGO, 
  ICG_AFRICA_LOGO, 
  SAINTE_VICTOIRE_LOGO, 
} from './defaultLogos';
import { db, auth } from '../firebase';
import {
  doc,
  setDoc,
  getDoc,
  collection,
  getDocs,
  query,
  where,
  deleteDoc,
  updateDoc,
  serverTimestamp,
  increment
} from 'firebase/firestore';

const CARDS_STORAGE_KEY = 'smart_qr_items_v2';
const CLIENTS_STORAGE_KEY = 'smart_qr_clients_v2';
const SCANS_STORAGE_KEY = 'smart_qr_scans_v2';
const HISTORY_STORAGE_KEY = 'smart_qr_history_v2';
const DESIGNER_STORAGE_KEY = 'smart_qr_designer_v2';
const DELETED_CARDS_KEY = 'smart_qr_deleted_ids_v1';
const DELETED_CLIENTS_KEY = 'smart_qr_deleted_clients_v1';

const ADMIN_EMAIL = 'atsegillesbrice@gmail.com';

export function getCurrentUser(): { uid: string; email?: string | null; displayName?: string | null } | null {
  if (auth?.currentUser) {
    return auth.currentUser;
  }
  try {
    const raw = localStorage.getItem('agb_user_session');
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.uid) return parsed;
    }
  } catch {}
  return null;
}

function getDeletedIdSet(storageKey: string): Set<string> {
  try {
    const raw = localStorage.getItem(storageKey);
    const parsed = raw ? JSON.parse(raw) : [];
    return new Set(Array.isArray(parsed) ? parsed.filter((value): value is string => typeof value === 'string') : []);
  } catch {
    return new Set();
  }
}

function normalizeTimestamp(value: any, fallback: string = new Date().toISOString()): string {
  if (typeof value === 'string' && value) return value;
  if (value?.toDate instanceof Function) {
    try { return value.toDate().toISOString(); } catch { return fallback; }
  }
  if (typeof value?.seconds === 'number') {
    return new Date(value.seconds * 1000).toISOString();
  }
  return fallback;
}

function normalizeFirestoreCard(data: any): QRCodeItem {
  const now = new Date().toISOString();
  const normalizedStatus = data?.status === 'PUBLISHED' ? 'active' : (data?.status || 'active');
  return {
    ...data,
    status: normalizedStatus,
    createdAt: normalizeTimestamp(data?.createdAt, now),
    updatedAt: normalizeTimestamp(data?.updatedAt, now),
    lastScannedAt: data?.lastScannedAt ? normalizeTimestamp(data.lastScannedAt, now) : undefined,
    expiresAt: data?.expiresAt ? normalizeTimestamp(data.expiresAt, now) : undefined
  } as QRCodeItem;
}

function normalizeFirestoreClient(data: any): ClientProfile {
  const now = new Date().toISOString();
  return {
    ...data,
    createdAt: normalizeTimestamp(data?.createdAt, now),
    updatedAt: normalizeTimestamp(data?.updatedAt, now)
  } as ClientProfile;
}

function removeUndefinedDeep<T>(value: T): T {
  if (Array.isArray(value)) {
    return value
      .map(item => removeUndefinedDeep(item))
      .filter(item => item !== undefined) as T;
  }
  if (value && typeof value === 'object') {
    const output: Record<string, unknown> = {};
    for (const [key, nestedValue] of Object.entries(value as Record<string, unknown>)) {
      if (nestedValue !== undefined) output[key] = removeUndefinedDeep(nestedValue);
    }
    return output as T;
  }
  return value;
}


export function resetLocalAppData(): void {
  [
    CARDS_STORAGE_KEY,
    CLIENTS_STORAGE_KEY,
    SCANS_STORAGE_KEY,
    HISTORY_STORAGE_KEY,
    DESIGNER_STORAGE_KEY,
    DELETED_CARDS_KEY,
    DELETED_CLIENTS_KEY
  ].forEach(key => localStorage.removeItem(key));
}

export const DEFAULT_DESIGNER_PROFILE: DesignerProfile = {
  name: 'Gilles Brice ATSÉ',
  agencyName: 'AGB Studio & Conception',
  logoUrl: AGB_ENGINEERING_LOGO,
  phone: '+225 01 04 00 00 00',
  whatsapp: '+225 01 04 00 00 00',
  email: 'atsegillesbrice@gmail.com',
  website: 'https://agb-solutions.ci',
  address: 'Cocody Riviera, Abidjan, Côte d\'Ivoire',
  slogan: 'Conception professionnelle de cartes de visite physiques connectées & fiches vCard sur mesure',
  defaultFormat: '85x55'
};

export const INITIAL_CLIENTS: ClientProfile[] = [
  {
    id: 'client_001',
    clientNumber: 'CLT-2026-0001',
    firstName: 'Gilles Brice',
    lastName: 'ATSÉ',
    fullName: 'Gilles Brice ATSÉ',
    company: 'AGB Digital Engineering',
    jobTitle: 'Concepteur d\'applications mobiles & Web',
    industry: 'Technologies',
    logoUrl: AGB_ENGINEERING_LOGO,
    primaryPhone: '+225 01 04 00 00 00',
    email: 'atsegillesbrice@gmail.com',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250104000000', displayOrder: 1 }],
    createdAt: '2026-08-10T08:00:00.000Z',
    updatedAt: '2026-08-21T08:00:00.000Z'
  },
  {
    id: 'client_002',
    clientNumber: 'CLT-2026-0002',
    firstName: 'Sarah',
    lastName: 'KOUASSI',
    fullName: 'Sarah KOUASSI',
    company: 'ICG Africa',
    jobTitle: 'Consultante en Stratégie & Finance',
    industry: 'Finance',
    logoUrl: ICG_AFRICA_LOGO,
    primaryPhone: '+225 07 07 00 00 00',
    email: 's.kouassi@icg-africa.com',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [{ id: 's1', platform: 'linkedin', url: 'https://linkedin.com', displayOrder: 1 }],
    createdAt: '2026-08-11T09:00:00.000Z',
    updatedAt: '2026-08-22T09:00:00.000Z'
  },
  {
    id: 'client_003',
    clientNumber: 'CLT-2026-0003',
    firstName: 'Marc',
    lastName: 'BAMBA',
    fullName: 'Dr. Marc BAMBA',
    company: 'Centre Médical Sainte-Victoire',
    jobTitle: 'Médecin Cardiologue',
    industry: 'Santé',
    logoUrl: SAINTE_VICTOIRE_LOGO,
    primaryPhone: '+225 05 05 00 00 00',
    email: 'dr.bamba@sainte-victoire.ci',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250505000000', displayOrder: 1 }],
    createdAt: '2026-08-12T10:00:00.000Z',
    updatedAt: '2026-08-23T10:00:00.000Z'
  },
  {
    id: 'client_004',
    clientNumber: 'CLT-2026-0004',
    firstName: 'Richmond',
    lastName: 'DONGO',
    fullName: 'Richmond DONGO',
    company: 'Canaan Services',
    jobTitle: 'Responsable Commercial',
    industry: 'Imprimerie',
    logoUrl: CANAAN_SERVICES_LOGO,
    primaryPhone: '+225 07 08 07 66 90',
    email: 'richmond.dongo@canaan.ci',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250708076690', displayOrder: 1 }],
    createdAt: '2026-08-13T11:00:00.000Z',
    updatedAt: '2026-09-23T08:30:00.000Z'
  },
  {
    id: 'client_005',
    clientNumber: 'CLT-2026-0005',
    firstName: 'Christophe',
    lastName: 'FODJO',
    fullName: 'Christophe FODJO',
    company: 'Canaan Services',
    jobTitle: 'Gérant',
    industry: 'Conseil',
    primaryPhone: '+225 05 66 41 62 10',
    email: 'c.fodjo@outlook.com',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250566416210', displayOrder: 1 }],
    createdAt: '2026-09-07T18:00:00.000Z',
    updatedAt: '2026-09-23T08:30:00.000Z'
  },
  {
    id: 'client_006',
    clientNumber: 'CLT-2026-0006',
    firstName: 'Eric Thierry',
    lastName: 'OHOUEU',
    fullName: 'Eric Thierry OHOUEU',
    company: 'MINISTÈRE DE L\'EMPLOI, DE LA PROTECTION SOCIALE ET DE LA FORMATION PROFESSIONNELLE',
    jobTitle: 'Administrateur du Travail et des Lois Sociales',
    industry: 'Administration Publique',
    primaryPhone: '+225 05 05 09 36 76',
    email: 'eric.ohoueu@travail.gouv.ci',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [
      { id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250505093676', displayOrder: 1 },
      { id: 's2', platform: 'phone', url: 'tel:+2250101202909', displayOrder: 2 }
    ],
    createdAt: '2026-09-07T18:00:00.000Z',
    updatedAt: '2026-09-07T18:00:00.000Z'
  },
  {
    id: 'client_007',
    clientNumber: 'CLT-2026-0007',
    firstName: 'Cyrille',
    lastName: 'ZÉZÉ',
    fullName: 'Cyrille ZÉZÉ',
    company: 'Cyrille ZÉZÉ Services',
    jobTitle: 'CADREUR - PHOTOGRAPHE - VIDÉASTE PROFESSIONNEL ET IMPRESSION SUR TOUS TYPES DE SUPPORTS',
    industry: 'Services & Photographie',
    primaryPhone: '+225 07 07 35 52 41',
    whatsappNumber: '+225 07 07 35 52 41',
    email: 'cyrille.zeze@gmail.com',
    city: 'Abidjan',
    country: 'Côte d\'Ivoire',
    socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250707355241', displayOrder: 1 }],
    createdAt: '2026-09-23T08:00:00.000Z',
    updatedAt: '2026-10-06T10:10:00.000Z'
  }
];

export const INITIAL_QR_ITEMS: QRCodeItem[] = [
  {
    id: 'qr_demo_01',
    cardNumber: 'CARD-2026-0001',
    publicId: 'AGB2026X',
    clientId: 'client_001',
    title: 'Gilles Brice ATSÉ — Concepteur d\'applications',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-10T08:00:00.000Z',
    updatedAt: '2026-08-21T08:00:00.000Z',
    scanCount: 184,
    content: {
      fullName: 'Gilles Brice ATSÉ',
      jobTitle: 'Concepteur d\'applications mobiles & Web',
      company: 'AGB Digital Engineering',
      logoUrl: AGB_ENGINEERING_LOGO,
      primaryPhone: '+225 01 04 00 00 00',
      email: 'atsegillesbrice@gmail.com',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250104000000', displayOrder: 1 }],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      cardBackgroundTheme: 'matte_dark',
      logoUrl: AGB_ENGINEERING_LOGO
    }
  },
  {
    id: 'qr_demo_02',
    cardNumber: 'CARD-2026-0002',
    publicId: 'ICG2026S',
    clientId: 'client_002',
    title: 'Sarah KOUASSI — Consultante Finance',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-11T09:00:00.000Z',
    updatedAt: '2026-08-22T09:00:00.000Z',
    scanCount: 45,
    content: {
      fullName: 'Sarah KOUASSI',
      jobTitle: 'Consultante en Stratégie & Finance',
      company: 'ICG Africa',
      logoUrl: ICG_AFRICA_LOGO,
      primaryPhone: '+225 07 07 00 00 00',
      email: 's.kouassi@icg-africa.com',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [{ id: 's1', platform: 'linkedin', url: 'https://linkedin.com', displayOrder: 1 }],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#1e293b',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'classy',
      eyeStyle: 'square',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      cardBackgroundTheme: 'navy_prestige',
      logoUrl: ICG_AFRICA_LOGO
    }
  },
  {
    id: 'qr_demo_03',
    cardNumber: 'CARD-2026-0003',
    publicId: 'MED2026M',
    clientId: 'client_003',
    title: 'Dr. Marc BAMBA — Cardiologie',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-12T10:00:00.000Z',
    updatedAt: '2026-08-23T10:00:00.000Z',
    scanCount: 120,
    content: {
      fullName: 'Dr. Marc BAMBA',
      jobTitle: 'Médecin Cardiologue',
      company: 'Centre Médical Sainte-Victoire',
      logoUrl: SAINTE_VICTOIRE_LOGO,
      primaryPhone: '+225 05 05 00 00 00',
      email: 'dr.bamba@sainte-victoire.ci',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250505000000', displayOrder: 1 }],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f766e',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      cardBackgroundTheme: 'emerald_luxe',
      logoUrl: SAINTE_VICTOIRE_LOGO
    }
  },
  {
    id: 'qr_demo_04',
    cardNumber: 'CARD-2026-0004',
    publicId: 'CAN2026R',
    clientId: 'client_004',
    title: 'Richmond DONGO — Responsable Commercial',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-13T11:00:00.000Z',
    updatedAt: '2026-09-23T08:30:00.000Z',
    scanCount: 68,
    content: {
      fullName: 'Richmond DONGO',
      jobTitle: 'Responsable Commercial',
      company: 'Canaan Services',
      logoUrl: CANAAN_SERVICES_LOGO,
      primaryPhone: '+225 07 08 07 66 90',
      whatsappNumber: '+225 07 08 07 66 90',
      email: 'richmond.dongo@canaan.ci',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250708076690', displayOrder: 1 }],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      eyeColor: '#d97706',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      bottomText: 'SCANNEZ POUR CONTACTER CANAAN SERVICES',
      cardBackgroundTheme: 'emerald_luxe',
      logoUrl: CANAAN_SERVICES_LOGO
    }
  },
  {
    id: 'qr_demo_05',
    publicId: 'BOOK2026',
    title: 'Livre Démo — L\'Art du Digital',
    type: 'BOOK',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-14T12:00:00.000Z',
    updatedAt: '2026-08-25T12:00:00.000Z',
    scanCount: 12,
    content: {
      bookTitle: 'L\'Art du Digital',
      bookAuthor: 'Gilles Brice ATSÉ',
      bookSummary: 'Un guide complet sur la transformation digitale en Afrique.',
      socialLinks: [],
      privacy: { isPublic: true }
    },
    styling: { fgColor: '#2563eb', bgColor: '#ffffff', transparentBg: false, moduleStyle: 'rounded', eyeStyle: 'rounded', errorCorrectionLevel: 'M', margin: 2, size: 300 }
  },
  {
    id: 'qr_demo_06',
    publicId: 'EVENT2026',
    title: 'Invitation — Gala AGB 2026',
    type: 'EVENT',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-15T13:00:00.000Z',
    updatedAt: '2026-08-26T13:00:00.000Z',
    scanCount: 89,
    content: {
      eventTitle: 'Gala Annuel AGB Digital',
      eventStartDate: '2026-12-20',
      eventLocationName: 'Hôtel Ivoire, Abidjan',
      socialLinks: [],
      privacy: { isPublic: true }
    },
    styling: { fgColor: '#7c3aed', bgColor: '#ffffff', transparentBg: false, moduleStyle: 'rounded', eyeStyle: 'rounded', errorCorrectionLevel: 'M', margin: 2, size: 300 }
  },
  {
    id: 'qr_demo_07',
    publicId: 'SHOP2026',
    title: 'Boutique — Canaan Gadgets',
    type: 'SHOP',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-16T14:00:00.000Z',
    updatedAt: '2026-08-27T14:00:00.000Z',
    scanCount: 156,
    content: {
      commercialName: 'Canaan Gadgets',
      shopIndustry: 'E-commerce & Personnalisation',
      socialLinks: [],
      privacy: { isPublic: true }
    },
    styling: { fgColor: '#059669', bgColor: '#ffffff', transparentBg: false, moduleStyle: 'rounded', eyeStyle: 'rounded', errorCorrectionLevel: 'M', margin: 2, size: 300 }
  },
  {
    id: 'qr_demo_08',
    publicId: 'LOC2026',
    title: 'Localisation — Siège AGB',
    type: 'LOCATION',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-08-17T15:00:00.000Z',
    updatedAt: '2026-08-28T15:00:00.000Z',
    scanCount: 34,
    content: {
      locationPlaceName: 'AGB Digital Headquarters',
      address: 'Riviera 3, Abidjan',
      latitude: 5.3599,
      longitude: -3.9870,
      socialLinks: [],
      privacy: { isPublic: true }
    },
    styling: { fgColor: '#475569', bgColor: '#ffffff', transparentBg: false, moduleStyle: 'rounded', eyeStyle: 'rounded', errorCorrectionLevel: 'M', margin: 2, size: 300 }
  },
  {
    id: 'qr_demo_09',
    cardNumber: 'CARD-2026-0009',
    publicId: 'EV6MKMQU',
    clientId: 'client_005',
    title: 'Christophe FODJO — Gérant',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-09-07T18:00:00.000Z',
    updatedAt: '2026-09-23T08:30:00.000Z',
    scanCount: 12,
    content: {
      fullName: 'Christophe FODJO',
      jobTitle: 'Gérant',
      company: 'Canaan Services',
      logoUrl: CANAAN_SERVICES_LOGO,
      primaryPhone: '+225 05 66 41 62 10',
      whatsappNumber: '+225 05 66 41 62 10',
      email: 'c.fodjo@outlook.com',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [{ id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250566416210', displayOrder: 1 }],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      eyeColor: '#6366f1',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      bottomText: 'SCANNEZ POUR ENREGISTRER',
      cardBackgroundTheme: 'white_classic',
      logoUrl: CANAAN_SERVICES_LOGO
    }
  },
  {
    id: 'qr_demo_10',
    cardNumber: 'CARD-2026-0010',
    publicId: 'GPKNURUP',
    clientId: 'client_006',
    title: 'Eric Thierry OHOUEU — Administrateur du Travail',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-09-07T18:00:00.000Z',
    updatedAt: '2026-09-23T08:30:00.000Z',
    scanCount: 0,
    content: {
      fullName: 'Eric Thierry OHOUEU',
      jobTitle: 'Administrateur du Travail et des Lois Sociales',
      company: 'MINISTÈRE DE L\'EMPLOI, DE LA PROTECTION SOCIALE ET DE LA FORMATION PROFESSIONNELLE',
      primaryPhone: '+225 05 05 09 36 76',
      whatsappNumber: '+225 05 05 09 36 76',
      email: 'eric.ohoueu@travail.gouv.ci',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [
        { id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250505093676', displayOrder: 1 },
        { id: 's2', platform: 'phone', url: 'tel:+2250101202909', displayOrder: 2 }
      ],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      eyeColor: '#6366f1',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      bottomText: 'SCANNEZ POUR ENREGISTRER',
      cardBackgroundTheme: 'navy_prestige'
    }
  },
  {
    id: 'qr_demo_11',
    cardNumber: 'CARD-2026-0011',
    publicId: 'CYR2026Z',
    clientId: 'client_007',
    title: 'Cyrille ZÉZÉ — Cadreur - Photographe - Vidéaste',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-09-23T08:00:00.000Z',
    updatedAt: '2026-10-06T10:10:00.000Z',
    scanCount: 0,
    content: {
      firstName: 'Cyrille',
      lastName: 'ZÉZÉ',
      fullName: 'Cyrille ZÉZÉ',
      jobTitle: 'CADREUR - PHOTOGRAPHE - VIDÉASTE PROFESSIONNEL ET IMPRESSION SUR TOUS TYPES DE SUPPORTS',
      company: 'Cyrille ZÉZÉ Services',
      primaryPhone: '+225 07 07 35 52 41',
      whatsappNumber: '+225 07 07 35 52 41',
      email: 'cyrille.zeze@gmail.com',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [
        { id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250707355241', displayOrder: 1 }
      ],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      eyeColor: '#2563eb',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      bottomText: 'SCANNEZ MOI',
      cardBackgroundTheme: 'white_classic'
    }
  },
  {
    id: 'qr_demo_12',
    cardNumber: 'CARD-2026-0012',
    publicId: 'ABD2026L',
    clientId: 'client_008',
    title: 'ABDOUL — Lunetterie',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-10-07T07:30:00.000Z',
    updatedAt: '2026-10-07T07:30:00.000Z',
    scanCount: 0,
    tags: ['Carte Pro', 'ABDOUL', 'Lunetterie'],
    content: {
      firstName: 'ABDOUL',
      fullName: 'ABDOUL',
      jobTitle: 'Lunetterie',
      company: 'Lunetterie Abdoul',
      workPhone: '+225 07 48 80 68 68',
      primaryPhone: '+225 07 48 80 68 68',
      whatsappNumber: '+225 07 48 80 68 68',
      address: 'YOPOUGON NON LOIN DE LA PHARMACIE SAINT ANDRÉ',
      neighborhood: 'YOPOUGON NON LOIN DE LA PHARMACIE SAINT ANDRÉ',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      socialLinks: [
        { id: 's1', platform: 'whatsapp', url: 'https://wa.me/2250748806868', displayOrder: 1 },
        { id: 's2', platform: 'phone', url: 'tel:+2250748806868', displayOrder: 2 }
      ],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      eyeColor: '#2563eb',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      bottomText: 'SCANNEZ MOI',
      cardBackgroundTheme: 'matte_dark'
    }
  },
  {
    id: 'qr_demo_13',
    cardNumber: 'CARD-2026-0013',
    publicId: 'MOI2026S',
    clientId: 'client_009',
    title: 'MOÏSE DEBLOWAD SAHOU — Administrateur Principal des Services Financiers',
    type: 'BUSINESS_CARD',
    mode: 'dynamic',
    status: 'active',
    createdAt: '2026-10-07T07:30:00.000Z',
    updatedAt: '2026-10-07T07:30:00.000Z',
    scanCount: 0,
    tags: ['Carte Pro', 'MOÏSE DEBLOWAD SAHOU', 'DGI'],
    content: {
      firstName: 'MOÏSE DEBLOWAD',
      lastName: 'SAHOU',
      fullName: 'MOÏSE DEBLOWAD SAHOU',
      jobTitle: 'ADMINISTRATEUR PRINCIPAL DES SERVICES FINANCIERS',
      company: 'Direction Générale des Impôts',
      commercialName: 'Direction Générale des Impôts (DGI)',
      department: 'Direction Générale des Impôts',
      email: 'moisesahou@gmail.com',
      workEmail: 'moisesahou@gmail.com',
      city: 'Abidjan',
      country: 'Côte d\'Ivoire',
      operatingZone: 'Abidjan, Côte d\'Ivoire',
      socialLinks: [
        { id: 's1', platform: 'email', url: 'mailto:moisesahou@gmail.com', displayOrder: 1 }
      ],
      privacy: { hideAddress: false }
    },
    styling: {
      fgColor: '#0f172a',
      bgColor: '#ffffff',
      transparentBg: false,
      moduleStyle: 'rounded',
      eyeStyle: 'rounded',
      eyeColor: '#2563eb',
      errorCorrectionLevel: 'H',
      margin: 3,
      size: 320,
      bottomText: 'SCANNEZ MOI',
      cardBackgroundTheme: 'navy_prestige'
    }
  }
];

export function getStoredQRCodes(): QRCodeItem[] {
  try {
    const data = localStorage.getItem(CARDS_STORAGE_KEY);
    const deletedData = localStorage.getItem(DELETED_CARDS_KEY);
    const deletedIds: string[] = deletedData ? JSON.parse(deletedData) : [];

    let items: QRCodeItem[] = data ? JSON.parse(data) : [];

    if (!Array.isArray(items)) {
      items = [];
    }

    let changed = false;

    INITIAL_QR_ITEMS.forEach(initItem => {
      if (!items.find(i => i && i.id === initItem.id) && !deletedIds.includes(initItem.id)) {
        items.push(initItem);
        changed = true;
      }
    });

    const uniqueMap = new Map<string, QRCodeItem>();
    items.forEach(item => {
      if (!item) return;
      const idKey = (item.publicId || item.id).trim().toUpperCase();
      const personKey = item.type === 'BUSINESS_CARD' && (item.content?.fullName || item.title)
        ? `PERSON_${(item.content?.fullName || item.title).trim().toLowerCase()}`
        : null;

      const existingById = uniqueMap.get(idKey);
      const existingByPerson = personKey ? uniqueMap.get(personKey) : null;
      const existing = existingById || existingByPerson;

      if (!existing || new Date(item.updatedAt).getTime() >= new Date(existing.updatedAt).getTime()) {
        if (existingByPerson && existingByPerson.publicId && existingByPerson.publicId !== item.publicId) {
          uniqueMap.delete(existingByPerson.publicId.trim().toUpperCase());
        }
        uniqueMap.set(idKey, item);
        if (personKey) uniqueMap.set(personKey, item);
      }
    });

    const deduplicated = Array.from(new Set(uniqueMap.values()));

    if (deduplicated.length !== items.length) {
      items = deduplicated;
      changed = true;
    }

    if (changed || !data) {
      saveQRCodes(items);
    }

    return items;
  } catch (e) {
    return INITIAL_QR_ITEMS;
  }
}

export function saveQRCodes(items: QRCodeItem[]): void {
  localStorage.setItem(CARDS_STORAGE_KEY, JSON.stringify(items));
}

export function getQRCodeById(id: string): QRCodeItem | undefined {
  return getStoredQRCodes().find(q => q.id === id);
}

export function getQRCodeByPublicId(publicId: string): QRCodeItem | undefined {
  if (!publicId) return undefined;
  const cleanId = publicId.trim().toLowerCase();
  return getStoredQRCodes().find(q =>
    (q && q.publicId && q.publicId.toLowerCase() === cleanId) ||
    (q && q.id && q.id.toLowerCase() === cleanId)
  );
}

export function encodeCardPayload(item: QRCodeItem): string {
  try {
    const cleanContent = { ...(item.content || {}) };
    if (cleanContent.photoUrl && cleanContent.photoUrl.startsWith('data:')) {
      delete cleanContent.photoUrl;
    }
    if (cleanContent.logoUrl && cleanContent.logoUrl.startsWith('data:')) {
      delete cleanContent.logoUrl;
    }

    const cleanStyling = { ...(item.styling || {}) };
    if (cleanStyling.logoUrl && cleanStyling.logoUrl.startsWith('data:')) {
      delete cleanStyling.logoUrl;
    }

    const compact: any = {
      id: item.id,
      pid: item.publicId,
      tt: item.title,
      tp: item.type,
      c: cleanContent,
      st: cleanStyling
    };
    const jsonStr = JSON.stringify(compact);
    return encodeURIComponent(btoa(unescape(encodeURIComponent(jsonStr))));
  } catch (e) {
    return '';
  }
}

export function decodeCardPayload(payload: string): QRCodeItem | null {
  if (!payload || typeof payload !== 'string') return null;
  try {
    let cleanStr = payload.trim();

    // First, try decoding URL percent-encoding if needed
    try {
      if (cleanStr.includes('%')) {
        cleanStr = decodeURIComponent(cleanStr);
      }
    } catch (e) {
      // ignore
    }

    // Convert URL-safe base64 characters back to standard base64
    cleanStr = cleanStr.replace(/-/g, '+').replace(/_/g, '/');

    // Restore missing base64 padding '='
    const mod = cleanStr.length % 4;
    if (mod === 2) cleanStr += '==';
    else if (mod === 3) cleanStr += '=';

    // Decode base64 to string
    let rawStr = '';
    try {
      rawStr = atob(cleanStr);
    } catch (e) {
      rawStr = atob(cleanStr.replace(/\s/g, ''));
    }

    // Try converting base64 string to UTF-8
    let jsonStr = rawStr;
    try {
      jsonStr = decodeURIComponent(escape(rawStr));
    } catch (e) {
      jsonStr = rawStr;
    }

    const compact = JSON.parse(jsonStr);
    if (!compact) return null;

    return {
      id: compact.id || `qr_${(compact.pid || Date.now()).toString().toLowerCase()}`,
      publicId: compact.pid || compact.publicId || 'PUBLIC_CARD',
      title: compact.tt || compact.title || 'Fiche Visite',
      type: compact.tp || compact.type || 'BUSINESS_CARD',
      mode: 'dynamic',
      status: 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      scanCount: 0,
      content: compact.c || compact.content || {},
      styling: compact.st || compact.styling || {}
    };
  } catch (e) {
    console.warn('Failed to decode card payload:', e);
    return null;
  }
}

export async function fetchQRCodeByPublicId(publicId: string, _preferServer = true): Promise<QRCodeItem | null> {
  if (!publicId) return null;
  const cleanId = publicId.trim();
  const upperDocId = cleanId.toUpperCase();

  const fetchFromFirestore = async (): Promise<QRCodeItem | null> => {
    if (!db) return null;
    try {
      // 1. Direct doc by upperDocId
      let cardSnap = await getDoc(doc(db, 'cards', upperDocId));
      if (cardSnap.exists()) {
        return normalizeFirestoreCard(cardSnap.data());
      }
      // 2. Direct doc by cleanId
      if (cleanId !== upperDocId) {
        cardSnap = await getDoc(doc(db, 'cards', cleanId));
        if (cardSnap.exists()) {
          return normalizeFirestoreCard(cardSnap.data());
        }
      }
      // 3. Query collection where publicId == cleanId or upperDocId
      const qPublic = query(collection(db, 'cards'), where('publicId', '==', cleanId));
      const snapPublic = await getDocs(qPublic);
      if (!snapPublic.empty) {
        return normalizeFirestoreCard(snapPublic.docs[0].data());
      }

      const qPublicUpper = query(collection(db, 'cards'), where('publicId', '==', upperDocId));
      const snapPublicUpper = await getDocs(qPublicUpper);
      if (!snapPublicUpper.empty) {
        return normalizeFirestoreCard(snapPublicUpper.docs[0].data());
      }

      // 4. Query collection where cardNumber == upperDocId
      const qCardNo = query(collection(db, 'cards'), where('cardNumber', '==', upperDocId));
      const snapCardNo = await getDocs(qCardNo);
      if (!snapCardNo.empty) {
        return normalizeFirestoreCard(snapCardNo.docs[0].data());
      }

      return null;
    } catch (err) {
      console.warn('Firestore fetch failed', err);
      return null;
    }
  };

  const serverFound = await fetchFromFirestore();
  const localFound = getQRCodeByPublicId(cleanId);
  const demoItem = INITIAL_QR_ITEMS.find(i =>
    i.publicId.toUpperCase() === upperDocId ||
    (i.cardNumber && i.cardNumber.toUpperCase() === upperDocId) ||
    i.id.toUpperCase() === upperDocId
  );

  const candidateList = [serverFound, localFound, demoItem].filter((c): c is QRCodeItem => c != null);

  if (candidateList.length > 0) {
    const latestItem = candidateList.reduce((newest, current) => {
      const newestTime = Date.parse(newest.updatedAt || '') || 0;
      const currentTime = Date.parse(current.updatedAt || '') || 0;
      return currentTime > newestTime ? current : newest;
    });

    if (db && latestItem) {
      const cardRef = doc(db, 'cards', upperDocId);
      setDoc(cardRef, {
        ...removeUndefinedDeep(latestItem),
        updatedAt: serverTimestamp()
      }, { merge: true }).catch(() => {});
    }

    return latestItem;
  }

  // Universal alias fallback for Cyrille ZÉZÉ
  if (
    upperDocId === 'CYR2026Z' ||
    upperDocId === 'CYRILLEZEZE' ||
    upperDocId === 'ZEZE' ||
    upperDocId.includes('ZEZE') ||
    upperDocId.includes('CYRILLE') ||
    upperDocId === 'CARD-2026-0011'
  ) {
    const cyrilleItem = INITIAL_QR_ITEMS.find(i => i.publicId === 'CYR2026Z');
    if (cyrilleItem) {
      if (db) {
        setDoc(doc(db, 'cards', upperDocId), removeUndefinedDeep(cyrilleItem), { merge: true }).catch(() => {});
        setDoc(doc(db, 'cards', 'CYR2026Z'), removeUndefinedDeep(cyrilleItem), { merge: true }).catch(() => {});
      }
      return cyrilleItem;
    }
  }

  // Universal alias fallback for ABDOUL
  if (
    upperDocId === 'ABD2026L' ||
    upperDocId === 'ABDOUL' ||
    upperDocId.includes('ABDOUL') ||
    upperDocId.includes('LUNETTERIE') ||
    upperDocId === 'CARD-2026-0012'
  ) {
    const abdoulItem = INITIAL_QR_ITEMS.find(i => i.publicId === 'ABD2026L');
    if (abdoulItem) {
      if (db) {
        setDoc(doc(db, 'cards', upperDocId), removeUndefinedDeep(abdoulItem), { merge: true }).catch(() => {});
        setDoc(doc(db, 'cards', 'ABD2026L'), removeUndefinedDeep(abdoulItem), { merge: true }).catch(() => {});
      }
      return abdoulItem;
    }
  }

  // Universal alias fallback for MOÏSE DEBLOWAD SAHOU
  if (
    upperDocId === 'MOI2026S' ||
    upperDocId === 'MOISE' ||
    upperDocId === 'SAHOU' ||
    upperDocId.includes('MOISE') ||
    upperDocId.includes('SAHOU') ||
    upperDocId.includes('DEBLOWAD') ||
    upperDocId === 'CARD-2026-0013'
  ) {
    const moiseItem = INITIAL_QR_ITEMS.find(i => i.publicId === 'MOI2026S');
    if (moiseItem) {
      if (db) {
        setDoc(doc(db, 'cards', upperDocId), removeUndefinedDeep(moiseItem), { merge: true }).catch(() => {});
        setDoc(doc(db, 'cards', 'MOI2026S'), removeUndefinedDeep(moiseItem), { merge: true }).catch(() => {});
      }
      return moiseItem;
    }
  }

  return null;
}

export function cleanQRCodeContent(content: QRContent, type: QRType): QRContent {
  if (!content) return {} as QRContent;

  const deepClean = (obj: any): any => {
    if (obj === null || obj === undefined) return undefined;
    if (typeof obj !== 'object') return obj === "" ? undefined : obj;

    if (Array.isArray(obj)) {
      const arr = obj.map(deepClean).filter(v =>
        v !== undefined && v !== null && (Array.isArray(v) ? v.length > 0 : true)
      );
      return arr.length > 0 ? arr : undefined;
    }

    const res: any = {};
    let hasKeys = false;
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        if (key === 'privacy' || key === 'customSections') {
          res[key] = obj[key];
          hasKeys = true;
          continue;
        }

        const val = deepClean(obj[key]);
        if (val !== undefined) {
          res[key] = val;
          hasKeys = true;
        }
      }
    }
    return hasKeys ? res : undefined;
  };

  const initialCleaned = deepClean(content) || {};
  const cleaned: any = {};

  const typePrefixMap: Record<string, string> = {
    'BOOK': 'book',
    'EVENT': 'event',
    'SHOP': 'shop',
    'COMPANY': 'company',
    'SOCIAL': 'social',
    'PRODUCT': 'product',
    'WEB_LINK': 'link',
    'LOCATION': 'location',
  };

  const currentPrefix = typePrefixMap[type];
  const otherPrefixes = Object.values(typePrefixMap).filter(p => p !== currentPrefix);

  for (const key in initialCleaned) {
    const value = initialCleaned[key];

    const commonFields = [
      'firstName', 'lastName', 'fullName', 'civility', 'middleName', 'jobTitle', 'profession',
      'company', 'department', 'industry', 'slogan', 'bio', 'photoUrl', 'logoUrl', 'bannerUrl',
      'primaryPhone', 'secondaryPhone', 'workPhone', 'whatsappNumber', 'email', 'workEmail',
      'websiteUrl', 'address', 'neighborhood', 'commune', 'city', 'region', 'postalCode', 'country',
      'latitude', 'longitude', 'privacy', 'customSections', 'customFields', 'openingHours', 'socialLinks'
    ];

    if (commonFields.includes(key)) {
      cleaned[key] = value;
      continue;
    }

    if (key === 'productSheetType' || key === 'menuItems' || key === 'serviceName') {
      if (type === 'PRODUCT') cleaned[key] = value;
      continue;
    }

    if (currentPrefix && key.startsWith(currentPrefix)) {
      cleaned[key] = value;
      continue;
    }

    if (otherPrefixes.some(p => key.startsWith(p))) {
      continue;
    }

    cleaned[key] = value;
  }

  return cleaned as QRContent;
}

export function saveOrUpdateQRCode(item: QRCodeItem, syncToServer = true): { item: QRCodeItem, isUpdate: boolean } {
  const items = getStoredQRCodes();
  const cleanedContent = cleanQRCodeContent(item.content, item.type);

  const deletedData = localStorage.getItem(DELETED_CARDS_KEY);
  if (deletedData) {
    const deletedIds: string[] = JSON.parse(deletedData);
    if (deletedIds.includes(item.id)) {
      localStorage.setItem(DELETED_CARDS_KEY, JSON.stringify(deletedIds.filter(id => id !== item.id)));
    }
  }

  let existingIdx = items.findIndex(q => q.id === item.id);
  if (existingIdx === -1 && item.publicId) {
    existingIdx = items.findIndex(q => q.publicId === item.publicId);
  }

  const isUpdate = existingIdx >= 0;

  const currentUser = getCurrentUser();

  const updatedItem: QRCodeItem = {
    ...(isUpdate ? items[existingIdx] : {}),
    ...item,
    content: cleanedContent,
    userId: currentUser?.uid || (isUpdate ? (items[existingIdx] as any).userId : item.userId),
    createdAt: isUpdate ? items[existingIdx].createdAt : (item.createdAt || new Date().toISOString()),
    updatedAt: new Date().toISOString()
  };

  if (isUpdate) {
    items[existingIdx] = updatedItem;
  } else {
    items.unshift(updatedItem);
  }

  saveQRCodes(items);

  if (syncToServer && db && updatedItem.publicId) {
    const firestoreUid = auth?.currentUser?.uid || currentUser?.uid || 'admin_agb_001';
    const cleanPublicId = updatedItem.publicId.trim().toUpperCase();
    const cloudItem = removeUndefinedDeep({ ...updatedItem, userId: firestoreUid });

    setDoc(doc(db, 'cards', cleanPublicId), {
      ...cloudItem,
      updatedAt: serverTimestamp()
    }).catch(err => console.error("Firestore sync failed:", err));

    if (updatedItem.publicId.trim() !== cleanPublicId) {
      setDoc(doc(db, 'cards', updatedItem.publicId.trim()), {
        ...cloudItem,
        updatedAt: serverTimestamp()
      }).catch(() => {});
    }

    if (updatedItem.cardNumber) {
      setDoc(doc(db, 'cards', updatedItem.cardNumber.trim().toUpperCase()), {
        ...cloudItem,
        updatedAt: serverTimestamp()
      }).catch(() => {});
    }
  }

  return { item: updatedItem, isUpdate };
}

export function deleteQRCode(id: string): void {
  const items = getStoredQRCodes();
  const target = items.find(q => q.id === id);

  if (target) {
    const deletedData = localStorage.getItem(DELETED_CARDS_KEY);
    const deletedIds: string[] = deletedData ? JSON.parse(deletedData) : [];
    if (!deletedIds.includes(id)) {
      deletedIds.push(id);
      localStorage.setItem(DELETED_CARDS_KEY, JSON.stringify(deletedIds));
    }
    saveQRCodes(items.filter(q => q.id !== id));
    if (db && auth?.currentUser && target.publicId) {
      deleteDoc(doc(db, 'cards', target.publicId)).catch(err => console.error("Firestore delete failed:", err));
    }
  }
}

export function duplicateQRCode(id: string): QRCodeItem | null {
  const original = getQRCodeById(id);
  if (!original) return null;
  const duplicate = {
    ...JSON.parse(JSON.stringify(original)),
    id: `qr_${Date.now()}`,
    publicId: generateSecurePublicId(),
    title: `${original.title} (Copie)`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    scanCount: 0,
    lastScannedAt: undefined
  };
  saveOrUpdateQRCode(duplicate);
  return duplicate;
}

export async function syncCardsWithServer(): Promise<QRCodeItem[]> {
  if (!db || !auth?.currentUser) return getStoredQRCodes();

  try {
    const userId = auth.currentUser.uid;
    const deletedCardIds = getDeletedIdSet(DELETED_CARDS_KEY);
    const deletedClientIds = getDeletedIdSet(DELETED_CLIENTS_KEY);

    const qCards = query(collection(db, 'cards'), where('userId', '==', userId));
    const cardSnaps = await getDocs(qCards);
    const serverCards = cardSnaps.docs
      .map(snapshot => normalizeFirestoreCard(snapshot.data()))
      .filter(card => !deletedCardIds.has(card.id));

    const localCards = getStoredQRCodes().filter(card => !deletedCardIds.has(card.id) && (!card.userId || card.userId === userId));
    const mergedCards = [...localCards];

    serverCards.forEach(sCard => {
      const idx = mergedCards.findIndex(lc => lc.id === sCard.id || lc.publicId === sCard.publicId);
      if (idx >= 0) {
        const localUpdatedAt = Date.parse(mergedCards[idx].updatedAt || '') || 0;
        const serverUpdatedAt = Date.parse(sCard.updatedAt || '') || 0;
        if (serverUpdatedAt >= localUpdatedAt) {
          mergedCards[idx] = { ...mergedCards[idx], ...sCard };
        } else {
          // Push newer local card from APK to Cloud Firestore
          if (db && mergedCards[idx].publicId) {
            const cleanPublicId = mergedCards[idx].publicId.trim().toUpperCase();
            setDoc(doc(db, 'cards', cleanPublicId), removeUndefinedDeep({ ...mergedCards[idx], userId })).catch(() => {});
          }
        }
      } else {
        mergedCards.push(sCard);
      }
    });

    // Push any local-only card created in APK to Cloud Firestore
    localCards.forEach(lCard => {
      const existsOnServer = serverCards.some(sc => sc.id === lCard.id || sc.publicId === lCard.publicId);
      if (!existsOnServer && lCard.publicId && db) {
        const cleanPublicId = lCard.publicId.trim().toUpperCase();
        setDoc(doc(db, 'cards', cleanPublicId), removeUndefinedDeep({ ...lCard, userId })).catch(() => {});
      }
    });

    saveQRCodes(mergedCards);

    const qClients = query(collection(db, 'clients'), where('userId', '==', userId));
    const clientSnaps = await getDocs(qClients);
    const serverClients = clientSnaps.docs
      .map(snapshot => normalizeFirestoreClient(snapshot.data()))
      .filter(client => !deletedClientIds.has(client.id));

    const localClients = getStoredClients().filter(client => !deletedClientIds.has(client.id) && (!client.userId || client.userId === userId));
    const mergedClients = [...localClients];

    serverClients.forEach(sClient => {
      const idx = mergedClients.findIndex(lc => lc.id === sClient.id);
      if (idx >= 0) {
        const localUpdatedAt = Date.parse(mergedClients[idx].updatedAt || '') || 0;
        const serverUpdatedAt = Date.parse(sClient.updatedAt || '') || 0;
        if (serverUpdatedAt >= localUpdatedAt) {
          mergedClients[idx] = { ...mergedClients[idx], ...sClient };
        }
      } else {
        mergedClients.push(sClient);
      }
    });

    saveClients(mergedClients);
    return mergedCards;
  } catch (err) {
    console.error('Sync error:', err);
    return getStoredQRCodes();
  }
}

export function getStoredClients(): ClientProfile[] {
  try {
    const data = localStorage.getItem(CLIENTS_STORAGE_KEY);
    const deletedData = localStorage.getItem(DELETED_CLIENTS_KEY);
    const deletedIds: string[] = deletedData ? JSON.parse(deletedData) : [];

    let clients: ClientProfile[] = data ? JSON.parse(data) : [];

    if (!Array.isArray(clients)) {
      clients = [];
    }

    let changed = false;
    INITIAL_CLIENTS.forEach(initClient => {
      if (!clients.find(c => c && c.id === initClient.id) && !deletedIds.includes(initClient.id)) {
        clients.push(initClient);
        changed = true;
      }
    });

    const uniqueMap = new Map<string, ClientProfile>();
    clients.forEach(c => {
      if (!c) return;
      const idKey = c.id;
      const nameKey = (c.fullName || `${c.firstName || ''} ${c.lastName || ''}`).trim().toLowerCase();

      const existingById = uniqueMap.get(idKey);
      const existingByName = nameKey ? uniqueMap.get(`NAME_${nameKey}`) : null;
      const existing = existingById || existingByName;

      if (!existing || new Date(c.updatedAt).getTime() >= new Date(existing.updatedAt).getTime()) {
        if (existingByName && existingByName.id !== c.id) {
          uniqueMap.delete(existingByName.id);
        }
        uniqueMap.set(idKey, c);
        if (nameKey) uniqueMap.set(`NAME_${nameKey}`, c);
      }
    });

    const deduplicated = Array.from(new Set(uniqueMap.values()));

    if (deduplicated.length !== clients.length) {
      clients = deduplicated;
      changed = true;
    }

    if (changed || !data) {
      saveClients(clients);
    }

    return clients;
  } catch (e) {
    return INITIAL_CLIENTS;
  }
}

export function deduplicateData(): void {
  getStoredClients();
  getStoredQRCodes();
}

export function saveClients(clients: ClientProfile[]): void {
  localStorage.setItem(CLIENTS_STORAGE_KEY, JSON.stringify(clients));
}

export function saveOrUpdateClient(client: Partial<ClientProfile> & { id?: string }): { client: ClientProfile, isUpdate: boolean } {
  const clients = getStoredClients();
  if (client.id) {
    const deletedIds = getDeletedIdSet(DELETED_CLIENTS_KEY);
    if (deletedIds.delete(client.id)) {
      localStorage.setItem(DELETED_CLIENTS_KEY, JSON.stringify(Array.from(deletedIds)));
    }
  }

  const existingIdx = client.id ? clients.findIndex(c => c.id === client.id) : -1;

  const isUpdate = existingIdx >= 0;
  const existing = isUpdate ? clients[existingIdx] : undefined;
  const id = existing?.id || client.id || `client_${Date.now()}`;
  const now = new Date().toISOString();
  const fullName = (client.fullName || `${client.firstName || ''} ${client.lastName || ''}`.trim() || client.company || existing?.fullName || 'Client').trim();

  const fullClient: ClientProfile = {
    ...(existing || {}),
    ...client,
    id,
    clientNumber: client.clientNumber || existing?.clientNumber || generateClientNumber(clients.length + 1),
    firstName: client.firstName ?? existing?.firstName ?? '',
    lastName: client.lastName ?? existing?.lastName ?? '',
    fullName,
    company: client.company ?? existing?.company ?? '',
    jobTitle: client.jobTitle ?? existing?.jobTitle ?? '',
    primaryPhone: client.primaryPhone ?? existing?.primaryPhone ?? '',
    email: client.email ?? existing?.email ?? '',
    city: client.city ?? existing?.city ?? 'Abidjan',
    country: client.country ?? existing?.country ?? "Côte d'Ivoire",
    socialLinks: client.socialLinks ?? existing?.socialLinks ?? [],
    userId: getCurrentUser()?.uid || existing?.userId,
    createdAt: existing?.createdAt || client.createdAt || now,
    updatedAt: now
  };

  if (isUpdate) clients[existingIdx] = fullClient;
  else clients.unshift(fullClient);
  saveClients(clients);

  // Propagate updated client details to associated cards and sync to Cloud Firestore
  try {
    const allCards = getStoredQRCodes();
    allCards.forEach(card => {
      if (
        card.clientId === fullClient.id ||
        (card.content?.fullName && card.content.fullName.trim().toLowerCase() === fullClient.fullName.trim().toLowerCase())
      ) {
        const updatedCard: QRCodeItem = {
          ...card,
          clientId: fullClient.id,
          title: `${fullClient.fullName} — ${fullClient.jobTitle || fullClient.company || 'Carte Pro'}`,
          content: {
            ...card.content,
            firstName: fullClient.firstName || card.content.firstName,
            lastName: fullClient.lastName || card.content.lastName,
            fullName: fullClient.fullName || card.content.fullName,
            company: fullClient.company || card.content.company,
            jobTitle: fullClient.jobTitle || card.content.jobTitle,
            primaryPhone: fullClient.primaryPhone || card.content.primaryPhone,
            secondaryPhone: fullClient.secondaryPhone || card.content.secondaryPhone,
            whatsappNumber: fullClient.whatsappNumber || card.content.whatsappNumber,
            workPhone: fullClient.workPhone || card.content.workPhone,
            email: fullClient.email || card.content.email,
            city: fullClient.city || card.content.city,
            country: fullClient.country || card.content.country,
            logoUrl: fullClient.logoUrl || card.content.logoUrl,
            photoUrl: fullClient.photoUrl || card.content.photoUrl,
            socialLinks: fullClient.socialLinks?.length ? fullClient.socialLinks : card.content.socialLinks,
            servicesOffered: fullClient.servicesList?.length ? fullClient.servicesList : card.content.servicesOffered
          },
          updatedAt: now
        };
        saveOrUpdateQRCode(updatedCard, true);
      }
    });
  } catch (err) {
    console.warn("Card propagation error:", err);
  }

  const activeUser = getCurrentUser();
  if (db && fullClient.id) {
    const firestoreUid = auth?.currentUser?.uid || activeUser?.uid || 'admin_agb_001';
    const clientRef = doc(db, 'clients', fullClient.id);
    const cloudClient = removeUndefinedDeep({ ...fullClient, userId: firestoreUid });
    setDoc(clientRef, {
      ...cloudClient,
      updatedAt: serverTimestamp()
    }).catch(err => console.error('Client Firestore sync failed:', err));
  }

  return { client: fullClient, isUpdate };
}

export function deleteClient(id: string): void {
  const clients = getStoredClients();
  const target = clients.find(client => client.id === id);
  const deletedIds = getDeletedIdSet(DELETED_CLIENTS_KEY);
  deletedIds.add(id);
  localStorage.setItem(DELETED_CLIENTS_KEY, JSON.stringify(Array.from(deletedIds)));
  saveClients(clients.filter(client => client.id !== id));

  if (target && db && auth?.currentUser) {
    deleteDoc(doc(db, 'clients', target.id)).catch(err => console.error('Client Firestore delete failed:', err));
  }
}

export function getStoredHistory(): HistoryLogItem[] {
  try {
    const data = localStorage.getItem(HISTORY_STORAGE_KEY);
    const parsed = data ? JSON.parse(data) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

export function addHistoryLog(log: Omit<HistoryLogItem, 'id' | 'timestamp'>): void {
  const history = getStoredHistory();
  history.unshift({ ...log, id: `hist_${Date.now()}`, timestamp: new Date().toISOString() });
  localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history.slice(0, 100)));
}

export function getDesignerProfile(): DesignerProfile {
  try {
    const data = localStorage.getItem(DESIGNER_STORAGE_KEY);
    return data ? JSON.parse(data) : DEFAULT_DESIGNER_PROFILE;
  } catch {
    return DEFAULT_DESIGNER_PROFILE;
  }
}

export function saveDesignerProfile(profile: DesignerProfile): void {
  localStorage.setItem(DESIGNER_STORAGE_KEY, JSON.stringify(profile));
}

export function getStoredScans(): ScanEvent[] {
  try {
    const data = localStorage.getItem(SCANS_STORAGE_KEY);
    const parsed = data ? JSON.parse(data) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) {
    return [];
  }
}

export function recordScanEvent(publicId: string): void {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  const deviceType: ScanEvent['deviceType'] = /iPad|Tablet|PlayBook|Silk/i.test(ua)
    ? 'tablet'
    : /Mobi|Android|iPhone|iPod/i.test(ua) ? 'mobile' : 'desktop';
  const os: ScanEvent['os'] = /iPhone|iPad|iPod/i.test(ua) ? 'iOS'
    : /Android/i.test(ua) ? 'Android'
    : /Windows/i.test(ua) ? 'Windows'
    : /Macintosh|Mac OS X/i.test(ua) ? 'macOS'
    : /Linux/i.test(ua) ? 'Linux' : 'Other';
  const browser: ScanEvent['browser'] = /SamsungBrowser/i.test(ua) ? 'Samsung Internet'
    : /Edg\//i.test(ua) ? 'Edge'
    : /Firefox\//i.test(ua) ? 'Firefox'
    : /Chrome\//i.test(ua) ? 'Chrome'
    : /Safari\//i.test(ua) ? 'Safari' : 'Other';

  const scan: ScanEvent = {
    id: `scan_${Date.now()}`,
    qrCodeId: publicId,
    publicId,
    timestamp: new Date().toISOString(),
    deviceType,
    os,
    browser,
    referrer: typeof document !== 'undefined' && document.referrer ? document.referrer : undefined
  };

  const scans = getStoredScans();
  scans.unshift(scan);
  localStorage.setItem(SCANS_STORAGE_KEY, JSON.stringify(scans.slice(0, 500)));

  // Public rules only allow an atomic +1 and a server timestamp on active cards.
  if (db && publicId && publicId !== 'direct_payload') {
    updateDoc(doc(db, 'cards', publicId), {
      scanCount: increment(1),
      lastScannedAt: serverTimestamp()
    }).catch(() => {
      // The card may be local-only/offline; the scan still remains in local analytics.
    });
  }
}

export function generateSecurePublicId(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(8);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
    return Array.from(bytes, value => alphabet[value % alphabet.length]).join('');
  }
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`.slice(-8).toUpperCase();
}

export function generateCardNumber(sequence: number, type: string = 'BUSINESS_CARD'): string {
  const seqStr = sequence.toString().padStart(6, '0');
  switch (type) {
    case 'BOOK': return `AGB-BOOK-${seqStr}`;
    case 'EVENT': return `AGB-EVT-${seqStr}`;
    case 'SHOP': return `AGB-SHOP-${seqStr}`;
    case 'LOCATION': return `AGB-LOC-${seqStr}`;
    case 'COMPANY': return `AGB-CO-${seqStr}`;
    case 'SOCIAL': return `AGB-SOC-${seqStr}`;
    case 'PRODUCT': return `AGB-PRD-${seqStr}`;
    case 'WEB_LINK': return `AGB-LNK-${seqStr}`;
    case 'CUSTOM': return `AGB-CUS-${seqStr}`;
    default: return `AGB-CARD-${seqStr}`;
  }
}

export function generateClientNumber(sequence: number): string {
  return `AGB-CLT-${sequence.toString().padStart(6, '0')}`;
}

const configuredPublicUrl = (import.meta.env.VITE_PUBLIC_APP_URL || '').trim();
export const CANONICAL_GITHUB_PAGES_URL = `${(configuredPublicUrl || 'https://agibrico.github.io/agibrico.github.io-/').replace(/\/+$/, '')}/`;

export function getPublicQRUrl(publicId: string, card?: QRCodeItem): string {
  const cleanId = (publicId || '').trim();
  const targetCard = card || getQRCodeByPublicId(cleanId);
  if (targetCard) {
    const payload = encodeCardPayload(targetCard);
    if (payload && payload.length < 2800) {
      return `${CANONICAL_GITHUB_PAGES_URL}#q/${encodeURIComponent(cleanId)}?d=${payload}`;
    }
  }
  return `${CANONICAL_GITHUB_PAGES_URL}#q/${encodeURIComponent(cleanId)}`;
}

export function getClientById(id: string): ClientProfile | undefined {
  return getStoredClients().find(c => c.id === id);
}

export async function syncOfficialDataToCloud(): Promise<void> {
  const currentUser = getCurrentUser();
  if (!db) return;
  const userId = auth?.currentUser?.uid || currentUser?.uid || 'admin_agb_001';

  try {
    const allCards = getStoredQRCodes();
    for (const card of allCards) {
      if (card.publicId) {
        const cleanPid = card.publicId.trim().toUpperCase();
        await setDoc(doc(db, 'cards', cleanPid), {
          ...removeUndefinedDeep(card),
          userId: card.userId || userId,
          updatedAt: serverTimestamp()
        }, { merge: true });

        if (card.cardNumber) {
          await setDoc(doc(db, 'cards', card.cardNumber.trim().toUpperCase()), {
            ...removeUndefinedDeep(card),
            userId: card.userId || userId,
            updatedAt: serverTimestamp()
          }, { merge: true });
        }

        if (cleanPid === 'CYR2026Z') {
          const aliases = ['CYRILLEZEZE', 'ZEZE', 'CARD-2026-0011'];
          for (const alias of aliases) {
            await setDoc(doc(db, 'cards', alias), {
              ...removeUndefinedDeep(card),
              userId: userId,
              updatedAt: serverTimestamp()
            }, { merge: true });
          }
        }
      }
    }
  } catch (err) {
    console.error('Data cloud sync failed:', err);
  }
}

export async function syncAllToCloud(): Promise<{ cards: number, clients: number }> {
  if (!db) throw new Error("Firebase Cloud non configuré.");
  const currentUser = getCurrentUser();
  const userId = auth?.currentUser?.uid || currentUser?.uid || 'admin_agb_001';

  const cards = getStoredQRCodes();
  const clients = getStoredClients();
  let cardsSynced = 0;
  let clientsSynced = 0;

  for (const card of cards) {
    if (card.publicId) {
      const cleanDocId = card.publicId.trim().toUpperCase();
      const cardRef = doc(db, 'cards', cleanDocId);
      await setDoc(cardRef, {
        ...removeUndefinedDeep(card),
        userId: card.userId || userId,
        updatedAt: serverTimestamp()
      }, { merge: true });
      cardsSynced++;
    }
  }

  for (const client of clients) {
    if (client.id) {
      const clientRef = doc(db, 'clients', client.id);
      await setDoc(clientRef, {
        ...removeUndefinedDeep(client),
        userId: client.userId || userId,
        updatedAt: serverTimestamp()
      }, { merge: true });
      clientsSynced++;
    }
  }

  return { cards: cardsSynced, clients: clientsSynced };
}

export function exportFullDatabaseJSON(): string {
  const db = {
    cards: getStoredQRCodes(),
    clients: getStoredClients(),
    scans: getStoredScans(),
    history: getStoredHistory(),
    designer: getDesignerProfile(),
    exportDate: new Date().toISOString(),
    version: '2.0'
  };
  return JSON.stringify(db, null, 2);
}

export function importFullDatabaseJSON(jsonStr: string): boolean {
  try {
    const data = JSON.parse(jsonStr);
    if (!Array.isArray(data.cards) || !Array.isArray(data.clients)) return false;
    const cards = data.cards.filter((card: any) => card && typeof card.id === 'string' && typeof card.publicId === 'string');
    const clients = data.clients.filter((client: any) => client && typeof client.id === 'string');
    saveQRCodes(cards);
    saveClients(clients);
    if (Array.isArray(data.scans)) localStorage.setItem(SCANS_STORAGE_KEY, JSON.stringify(data.scans));
    if (Array.isArray(data.history)) localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(data.history));
    if (data.designer) saveDesignerProfile(data.designer);
    return true;
  } catch (e) {
    return false;
  }
}
